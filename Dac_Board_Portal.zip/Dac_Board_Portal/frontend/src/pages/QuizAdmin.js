import React from 'react';
import "./as.css";
function QuizAdmin() {
  return (
    <div className='QuizAdmin'>
      <h1>Admin Quiz Page</h1>
    </div>
  );
}

export default QuizAdmin;