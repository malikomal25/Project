package com.househelp.service;


import com.househelp.beans.Customer;
import com.househelp.beans.MaidFeedback;



public interface ICustomerService {

	public void registerCustomer(Customer customer);
	 
}
