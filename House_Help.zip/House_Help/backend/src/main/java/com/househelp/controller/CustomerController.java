package com.househelp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.househelp.beans.Customer;
import com.househelp.beans.MaidMaster;
import com.househelp.beans.User;
import com.househelp.model.CustomerModel;
import com.househelp.model.LoginModel;
import com.househelp.model.LoginResponseModel;
import com.househelp.model.RegisterMaidModel;
import com.househelp.service.ICustomerService;
import com.househelp.service.IMaidService;
import com.househelp.service.IUserService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	 @Autowired
	 ICustomerService customerService;
	 
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	 public ResponseEntity registerCustomer(@RequestBody CustomerModel model) {
	  
		Customer customer = new Customer();
		
		customer.setAddress(model.getAddress());
		customer.setEmail_ID(model.getEmail_ID());
		customer.setGender(model.getGender());
		customer.setMobile_no(model.getMobile_no());
		customer.setName(model.getName());
		customer.setPassword(model.getPassword());
		customer.setPincode(model.getPincode());
		
		
		customerService.registerCustomer(customer);		
		return new ResponseEntity<>("Customer details registered successfully", HttpStatus.CREATED);
	 }
	
	
}
