package com.househelp.service;
import java.util.List;

import com.househelp.beans.User;



public interface IUserService {
		
		public void createUser(User user);
		public List<User> getUser();
		public void deleteUserById(int id);
 
}
