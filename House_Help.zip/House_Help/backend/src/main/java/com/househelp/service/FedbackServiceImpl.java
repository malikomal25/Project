package com.househelp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.househelp.beans.MaidFeedback;
import com.househelp.beans.MaidMaster;
import com.househelp.repo.FeedbackRepository;
import com.househelp.repo.MaidRepository;


@Service
@Transactional
public class FedbackServiceImpl implements IMaidFeedback {

	
	@Autowired
	private FeedbackRepository feedbackRepository;

	@Override
	public void registerFeedback(MaidFeedback feedback) {
		// TODO Auto-generated method stub
		feedbackRepository.save(feedback);	
	}
	
	
	

}

