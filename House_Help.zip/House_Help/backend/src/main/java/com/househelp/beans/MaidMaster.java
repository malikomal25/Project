package com.househelp.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "maid_master")
public class MaidMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int maid_id;
	private String NAME;
	private String Address;
	private int pin_code;
	private String mobile_no;
	private String DOB;
	private String gender;
	private float age;
	private String aadhar_no;
	private String photo;
	private String email_id;
	private String PASSWORD;
	
	private String category;
	 private int experience;
	 private float salary;
	 private String city;
	
	@OneToMany()
	@JoinColumn(name="maid_id", referencedColumnName="maid_id")
    List<MaidFeedback> feedback = new ArrayList<>();

	// Getter Methods

	public int getMaid_id() {
		return maid_id;
	}

	public String getNAME() {
		return NAME;
	}

	public String getAddress() {
		return Address;
	}

	public float getPin_code() {
		return pin_code;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public String getDOB() {
		return DOB;
	}

	public String getGender() {
		return gender;
	}

	public float getAge() {
		return age;
	}

	public String getAadhar_no() {
		return aadhar_no;
	}

	public String getPhoto() {
		return photo;
	}

	public String getEmail_id() {
		return email_id;
	}

	public String getPASSWORD() {
		return PASSWORD;
	}

	// Setter Methods

	public void setMaid_id(int maid_id) {
		this.maid_id = maid_id;
	}

	public void setNAME(String NAME) {
		this.NAME = NAME;
	}

	public void setAddress(String Address) {
		this.Address = Address;
	}

	public void setPin_code(int pin_code) {
		this.pin_code = pin_code;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public void setDOB(String DOB) {
		this.DOB = DOB;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public void setPASSWORD(String PASSWORD) {
		this.PASSWORD = PASSWORD;
	}

	public List<MaidFeedback> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<MaidFeedback> feedback) {
		this.feedback = feedback;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "MaidMaster [maid_id=" + maid_id + ", NAME=" + NAME + ", Address=" + Address + ", pin_code=" + pin_code
				+ ", mobile_no=" + mobile_no + ", DOB=" + DOB + ", gender=" + gender + ", age=" + age + ", aadhar_no="
				+ aadhar_no + ", photo=" + photo + ", email_id=" + email_id + ", PASSWORD=" + PASSWORD + ", category="
				+ category + ", experience=" + experience + ", salary=" + salary + ", city=" + city + ", feedback="
				+ feedback + "]";
	}

}
