package com.househelp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.househelp.beans.MaidMaster;
import com.househelp.repo.MaidRepository;


@Service
@Transactional
public class MaidServiceImpl implements IMaidService {

	
	@Autowired
	private MaidRepository maidRepository;
	
	@Override
	public void registerMaid(MaidMaster maid) {		
		maidRepository.save(maid);		 
	}

	@Override
	public List<MaidMaster> findMaidMasterByEmailAndPass(String email, String pass) {
		return maidRepository.findMaidMasterByEmailAndPass(email, pass);
	}
	
	@Override
	public void deleteMaidById(int maid_id) {		
		maidRepository.deleteMaidById(maid_id);		
	}	
	
	public List<MaidMaster> findAllMaids() {		
		return maidRepository.findAllMaids();		 
	}

	@Override
	public List<MaidMaster> searchMaids(String city, int pincode) {
		return maidRepository.searchMaids(city, pincode);
	}

	

}

