package com.househelp.model;

public class RegisterMaidModel {

	private int maid_id;
	private String NAME;
	private String Address;
	private int pin_code;
	private String mobile_no;
	private String DOB;
	private String gender;
	private float age;
	private String aadhar_no;
	private String photo;
	private String email_id;
	private String PASSWORD;
	private String category;
	 private int experience;
	 private int salary;
	 private String city;
	

	// Getter Methods

	public float getMaid_id() {
		return maid_id;
	}

	public String getNAME() {
		return NAME;
	}

	public String getAddress() {
		return Address;
	}

	public int getPin_code() {
		return pin_code;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public String getDOB() {
		return DOB;
	}

	public String getGender() {
		return gender;
	}

	public float getAge() {
		return age;
	}

	public String getAadhar_no() {
		return aadhar_no;
	}

	public String getPhoto() {
		return photo;
	}

	public String getEmail_id() {
		return email_id;
	}

	public String getPASSWORD() {
		return PASSWORD;
	}
	

	public float getSalary() {
		return salary;
	}

	// Setter Methods

	public void setMaid_id(int maid_id) {
		this.maid_id = maid_id;
	}

	public void setNAME(String NAME) {
		this.NAME = NAME;
	}

	public void setAddress(String Address) {
		this.Address = Address;
	}

	public void setPin_code(int pin_code) {
		this.pin_code = pin_code;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public void setDOB(String DOB) {
		this.DOB = DOB;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public void setPASSWORD(String PASSWORD) {
		this.PASSWORD = PASSWORD;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	

}
