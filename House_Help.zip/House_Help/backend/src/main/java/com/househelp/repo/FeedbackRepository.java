package com.househelp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.househelp.beans.MaidFeedback;
import com.househelp.beans.MaidMaster;

public interface FeedbackRepository extends JpaRepository<MaidFeedback, Integer> {

}
