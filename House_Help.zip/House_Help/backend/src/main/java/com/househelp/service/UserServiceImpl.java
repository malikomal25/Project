package com.househelp.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.househelp.beans.User;
import com.househelp.repo.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository userRepository;

	public List<User> getUser() {

		User a = new User();
		a.setCountry("a");
		a.setName("b");
		a.setId(9);
		this.createUser(a);
		return userRepository.findByActiveNotes();
	}

	public List<User> getUserById(int id) {
		// TODO Auto-generated method stub

		List<Integer> a = new ArrayList<Integer>();

		a.add(Integer.valueOf(id));

		return userRepository.findAllById(a);
	}

	public void createUser(User user) {
		// TODO Auto-generated method stub
		userRepository.save(user);
	}

	public void deleteUserById(int id) {
		// TODO Auto-generated method stub
		
	}

}
