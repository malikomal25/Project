package com.househelp.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class CustomerModel {
	
	 private String name;
	 private String gender;
	 private String address;
	 private String pincode;
	 private String mobile_no;
	 private String email_ID;
	 private String Password;



	 public String getName() {
	  return name;
	 }

	 public String getGender() {
	  return gender;
	 }

	 public String getAddress() {
	  return address;
	 }

	 public String getPincode() {
	  return pincode;
	 }

	 public String getMobile_no() {
	  return mobile_no;
	 }

	 public String getEmail_ID() {
	  return email_ID;
	 }

	 public String getPassword() {
	  return Password;
	 }


	 public void setName(String name) {
	  this.name = name;
	 }

	 public void setGender(String gender) {
	  this.gender = gender;
	 }

	 public void setAddress(String address) {
	  this.address = address;
	 }

	 public void setPincode(String pincode) {
	  this.pincode = pincode;
	 }

	 public void setMobile_no(String mobile_no) {
	  this.mobile_no = mobile_no;
	 }

	 public void setEmail_ID(String email_ID) {
	  this.email_ID = email_ID;
	 }

	 public void setPassword(String Password) {
	  this.Password = Password;
	 }

}
