package com.househelp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.househelp.repo.UserRepository;
import com.househelp.service.UserServiceImpl;


@SpringBootApplication(scanBasePackages={"com.househelp"})
@EnableJpaRepositories(basePackageClasses = { UserRepository.class, UserServiceImpl.class }) 
public class HousehelpApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(HousehelpApplication.class, args);
	}

}
