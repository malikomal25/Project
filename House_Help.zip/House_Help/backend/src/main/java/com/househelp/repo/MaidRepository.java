package com.househelp.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.househelp.beans.MaidMaster;
import com.househelp.beans.User;

public interface MaidRepository extends JpaRepository<MaidMaster, Integer> {

	
	@Query("SELECT n FROM MaidMaster n where email_id=?1 and password = ?2")
	List<MaidMaster> findMaidMasterByEmailAndPass(String emailAddress, String password);

	@Transactional
	@Modifying
	@Query("Delete from MaidMaster m where m.maid_id = ?1")
	void deleteMaidById(int maid_id);
	
	
	@Query("select n from MaidMaster n")
	List<MaidMaster> findAllMaids();
	
	
	@Query("select n from MaidMaster n where city=?1 or pin_code=?2")
	List<MaidMaster> searchMaids(String city, int pincode);
}
