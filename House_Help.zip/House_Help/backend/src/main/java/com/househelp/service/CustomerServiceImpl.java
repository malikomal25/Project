package com.househelp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.househelp.beans.Customer;
import com.househelp.beans.MaidMaster;
import com.househelp.repo.CustomerRepository;
import com.househelp.repo.MaidRepository;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	
	@Autowired
	private CustomerRepository customerRepository;
	


	@Override
	public void registerCustomer(Customer customer) {
		customerRepository.save(customer);		
		
	}



	

}

