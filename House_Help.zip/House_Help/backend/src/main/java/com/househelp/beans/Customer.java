package com.househelp.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "customer")
@JsonIgnoreProperties({
 "hibernateLazyInitializer",
 "handler"
})
public class Customer {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cust_id;
	 private String name;
	 private String gender;
	 private String address;
	 private String pincode;
	 private String mobile_no;
	 private String email_ID;
	 private String Password;


	 // Getter Methods 

	 public int getCust_id() {
	  return cust_id;
	 }

	 public String getName() {
	  return name;
	 }

	 public String getGender() {
	  return gender;
	 }

	 public String getAddress() {
	  return address;
	 }

	 public String getPincode() {
	  return pincode;
	 }

	 public String getMobile_no() {
	  return mobile_no;
	 }

	 public String getEmail_ID() {
	  return email_ID;
	 }

	 public String getPassword() {
	  return Password;
	 }

	 // Setter Methods 

	 public void setCust_id(int cust_id) {
	  this.cust_id = cust_id;
	 }

	 public void setName(String name) {
	  this.name = name;
	 }

	 public void setGender(String gender) {
	  this.gender = gender;
	 }

	 public void setAddress(String address) {
	  this.address = address;
	 }

	 public void setPincode(String pincode) {
	  this.pincode = pincode;
	 }

	 public void setMobile_no(String mobile_no) {
	  this.mobile_no = mobile_no;
	 }

	 public void setEmail_ID(String email_ID) {
	  this.email_ID = email_ID;
	 }

	 public void setPassword(String Password) {
	  this.Password = Password;
	 }

}
