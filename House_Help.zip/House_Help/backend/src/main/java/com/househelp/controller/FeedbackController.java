package com.househelp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.househelp.beans.MaidFeedback;
import com.househelp.beans.MaidMaster;
import com.househelp.beans.User;
import com.househelp.model.FeedbackModel;
import com.househelp.model.LoginModel;
import com.househelp.model.LoginResponseModel;
import com.househelp.model.RegisterMaidModel;
import com.househelp.service.IMaidFeedback;
import com.househelp.service.IMaidService;
import com.househelp.service.IUserService;

@RestController
@RequestMapping("/maid")
public class FeedbackController {
	
	 @Autowired
	 IMaidFeedback feedbackService;
	 
	@RequestMapping(value = "/feedback", method = RequestMethod.POST)
	 public ResponseEntity registerMaidDetails(@RequestBody FeedbackModel maidDetails) {
	  
		MaidFeedback feedback = new MaidFeedback();
		feedback.setCust_id(maidDetails.getCust_id());
		feedback.setRating(maidDetails.getRating());
		feedback.setWork_disc(maidDetails.getWork_disc());		
		feedback.setMaid_id(maidDetails.getMaid_id());
		
		
		
		feedbackService.registerFeedback(feedback);
			
		return new ResponseEntity<>("Maid details registered successfully", HttpStatus.CREATED);
	 }
	
	


	

}
