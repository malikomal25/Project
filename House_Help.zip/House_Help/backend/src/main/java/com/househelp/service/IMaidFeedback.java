package com.househelp.service;


import com.househelp.beans.MaidFeedback;



public interface IMaidFeedback {

	public void registerFeedback(MaidFeedback feedback);
	 
}
