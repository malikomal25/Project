package com.househelp.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.househelp.beans.MaidMaster;

public class FeedbackModel {
	

	 private int cust_id;
	 
	 private String work_disc;
	 private int rating;
	 private int maid_id;
	 
	 public int getCust_id() {
	  return cust_id;
	 }



	 public String getWork_disc() {
	  return work_disc;
	 }

	 public int getRating() {
	  return rating;
	 }



	 public void setCust_id(int cust_id) {
	  this.cust_id = cust_id;
	 }



	 public void setWork_disc(String work_disc) {
	  this.work_disc = work_disc;
	 }

	 public void setRating(int rating) {
	  this.rating = rating;
	 }



	public int getMaid_id() {
		return maid_id;
	}



	public void setMaid_id(int maid_id) {
		this.maid_id = maid_id;
	}



	 

}
