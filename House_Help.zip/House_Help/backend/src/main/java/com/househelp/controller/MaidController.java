package com.househelp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.househelp.beans.MaidMaster;
import com.househelp.beans.User;
import com.househelp.model.LoginModel;
import com.househelp.model.LoginResponseModel;
import com.househelp.model.RegisterMaidModel;
import com.househelp.service.IMaidService;
import com.househelp.service.IUserService;

@RestController
@CrossOrigin()
@RequestMapping("/maid")
public class MaidController {
	
	 @Autowired
	 IMaidService maidService;
	 
	@RequestMapping(value = "/", method = RequestMethod.POST)
	 public ResponseEntity registerMaidDetails(@RequestBody RegisterMaidModel maidDetails) {
	  
		MaidMaster maidMaster = new MaidMaster();
		
		maidMaster.setAadhar_no(maidDetails.getAadhar_no());
		maidMaster.setAddress(maidDetails.getAddress());
		maidMaster.setAge(maidDetails.getAge());
		maidMaster.setDOB(maidDetails.getDOB());
		maidMaster.setEmail_id(maidDetails.getEmail_id());
		maidMaster.setGender(maidDetails.getGender());
		maidMaster.setMobile_no(maidDetails.getMobile_no());		
		maidMaster.setNAME(maidDetails.getNAME());
		maidMaster.setPASSWORD(maidDetails.getPASSWORD());		
		maidMaster.setPhoto(maidDetails.getPhoto());
		maidMaster.setPin_code(maidDetails.getPin_code());
		maidMaster.setCategory(maidDetails.getCategory());
		maidMaster.setExperience(maidDetails.getExperience());
		maidMaster.setSalary(maidDetails.getSalary());
		maidMaster.setCity(maidDetails.getCity());
		
		System.out.println(maidMaster);
		maidService.registerMaid(maidMaster);		
		return new ResponseEntity<>("Maid details registered successfully", HttpStatus.CREATED);
	 }
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	 public ResponseEntity loginUser(@RequestBody LoginModel loginModel) {
	  
		
		List<MaidMaster> userDetails = maidService.findMaidMasterByEmailAndPass(loginModel.getEmailId(), loginModel.getPassword());
		
		if(userDetails == null || userDetails.isEmpty())
			return new ResponseEntity<>("Invalid email or password", HttpStatus.UNAUTHORIZED);
	
		LoginResponseModel model = new LoginResponseModel();
		model.setEmailId(loginModel.getEmailId());
		model.setToken(loginModel.getEmailId());
		
		return new ResponseEntity<>(model, HttpStatus.OK);
	 }
	
	
	@DeleteMapping("/MaidMaster/{maid_id}")
	public ResponseEntity deleteMaidById(@PathVariable("maid_id")int maid_id) {
		maidService.deleteMaidById(maid_id);
		System.out.println("deleted");
		return new ResponseEntity<>("maid deleted", HttpStatus.OK);
	}
	
	
	@GetMapping("/MaidMaster")
	public ResponseEntity findAllMaids(@RequestParam(required = false) String city, @RequestParam(required = false) Integer pincode) {
		
		List<MaidMaster> details;
		if(city != null || (pincode != null && pincode > 0)) {
			
			if(pincode == null)
				pincode = Integer.valueOf(0);
			
			details= maidService.searchMaids(city, pincode);
		} else {
			details= maidService.findAllMaids();
		}
		System.out.println("displayed");
		
		
		
		return new ResponseEntity<>(details, HttpStatus.OK);
	}
	

}
