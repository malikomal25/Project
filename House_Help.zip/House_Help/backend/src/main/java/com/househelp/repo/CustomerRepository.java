package com.househelp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.househelp.beans.Customer;
import com.househelp.beans.MaidFeedback;
import com.househelp.beans.MaidMaster;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
