package com.househelp.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "feedback")
@JsonIgnoreProperties({
 "hibernateLazyInitializer",
 "handler"
})
public class MaidFeedback {
	
	

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int uid;
	 private int cust_id;
	 private int maid_id;
	 private String work_disc;
	 private int rating;


	 // Getter Methods 

	 public int getUid() {
	  return uid;
	 }

	 public int getCust_id() {
	  return cust_id;
	 }

	 public int getMaid_id() {
	  return maid_id;
	 }

	 public String getWork_disc() {
	  return work_disc;
	 }

	 public int getRating() {
	  return rating;
	 }

	 // Setter Methods 

	 public void setUid(int uid) {
	  this.uid = uid;
	 }

	 public void setCust_id(int cust_id) {
	  this.cust_id = cust_id;
	 }

	 public void setMaid_id(int maid_id) {
	  this.maid_id = maid_id;
	 }

	 public void setWork_disc(String work_disc) {
	  this.work_disc = work_disc;
	 }

	 public void setRating(int rating) {
	  this.rating = rating;
	 }

	    
}
