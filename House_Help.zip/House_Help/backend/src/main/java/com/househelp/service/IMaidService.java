package com.househelp.service;

import java.util.List;

import com.househelp.beans.MaidMaster;


public interface IMaidService {

	public void registerMaid(MaidMaster maid);
	
	public List<MaidMaster> findMaidMasterByEmailAndPass(String email, String pass);
	
	public void deleteMaidById(int maid_id);
	
	public List<MaidMaster> findAllMaids();
	
	
	public List<MaidMaster> searchMaids(String city, int pincode);

	
	 
}
