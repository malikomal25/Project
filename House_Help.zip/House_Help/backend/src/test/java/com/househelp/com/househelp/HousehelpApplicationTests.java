package com.househelp.com.househelp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousehelpApplicationTests {

	@Test
	void contextLoads() {
	}

}
