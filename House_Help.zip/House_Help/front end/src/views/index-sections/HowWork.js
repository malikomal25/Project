 
import React from "react";
// plugin that creates slider
import Slider from "nouislider";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

function HowWork() {
  return (
    <>
      <div className="section section-how-work">
        <Container>
          <div className="title">
            <h2>How it Works</h2>
            <p>Book your desired service, hassle free process</p>
          </div>
          <Row>
            <Col lg="4" sm="6">
             <div className="work-box">
                <div className="work-icon">
                  <img src={require("assets/img/maid.png").default} />
                </div>
                <h3>Select Desired <br/> Service</h3>
             </div>
            </Col>
            <Col lg="4" sm="6">
             <div className="work-box">
                <div className="work-icon">
                  <img src={require("assets/img/location.png").default} />
                </div>
                <h3>Fill Your <br/> Requirements</h3>
             </div>
            </Col>
            <Col lg="4" sm="6">
             <div className="work-box">
                <div className="work-icon">
                  <img src={require("assets/img/handshake.png").default} />
                </div>
                <h3>Try and <br/> Finalize</h3>
             </div>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default HowWork;
