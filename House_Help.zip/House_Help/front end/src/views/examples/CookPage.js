import React from "react";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import CookHeader from "components/Headers/CookHeader.js";
import Advantages from "views/index-sections/Advantages.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function CookPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <CookHeader />
      <div className="section service-content">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto text-center" md="8">
              <h2 className="sub-title">Are You Looking For A Cook?</h2>
              <p className="about-info">
              is an on demand leading service provider helping customers to save time while you can enjoy home cooked meal and the joy that comes with it. We help customers to find professional cooks who can cook best delicious food for your family.  
              </p>
              <p className="about-info">Our workers are well trained and well familiar about all dishes/recipes. Our cooks have received a commendable position in the market due to their highly skilled quality services.</p>
            </Col>
          </Row>
        </Container>
      </div>
      <Advantages />
      <DemoFooter />
    </>
  );
}

export default CookPage;
