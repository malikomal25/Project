 
import React, { useEffect, useState } from "react";

// reactstrap components
import {
  Button,
  Card,
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import DashboardNavbar from "components/Navbars/DashboardNavbar.js";
import SerachHeader from "components/Headers/SerachHeader.js";
import DemoFooter from "components/Footers/DemoFooter.js";
import axios from "axios";
import IndexNavbar from "components/Navbars/IndexNavbar";


function DashboardPage(props) {
  document.documentElement.classList.remove("nav-open");
  const [maid, setMaid] = useState([]);

  React.useEffect(() => {
    document.body.classList.add("profile-page");
    return function cleanup() {
      document.body.classList.remove("profile-page");
    };
  });
  useEffect(()=>{
	  search()
  },[])
  // const workerList = (
  //   <ul>
  //     {props.posts.map((worker) =>
  //       <div className="worker-details" key={worker.id}>
  //       <div className="worker worker-name">{worker.name} </div>
  //       <div className="worker worker-age"> {worker.age} </div>
  //     </div>
  //     )}
  //   </ul>
  // );
  // const worker = [
  //   {id: 1, name: 'Savita sutar', age: '29'},
  //   {id: 1, name: 'Vikas singh', age: '19'},
  // ];
  const searchText = (data) =>{
		search(data)
	}
  const search = async(data)=>{
	  let url = 'http://househelpproject-env.eba-pcuqxb83.ap-south-1.elasticbeanstalk.com/maid/MaidMaster' ;
	  if(data){
		url = 'http://househelpproject-env.eba-pcuqxb83.ap-south-1.elasticbeanstalk.com/maid/MaidMaster?address='+data ;
	  }
	  try{
		const response = await axios.get(url);
		setMaid(response.data)
		}catch(e){

	  }

  }
  return (
    <>
      <IndexNavbar />
      <SerachHeader searchText={(data)=>searchText(data)} />
      <div className="main">
        <div className="section">
          <Container>
            <Row>
              <Col className="ml-auto mr-auto" md="10">
                <h2 className="title">Professional and Reliable Workers List</h2>
                <div className="worker-list-box">
                  <Row>
						{
							maid.map(m=>{
								return(
                  <Col md="6">
									<Card className="worker-box">
										<div className="worker-image">
											<img src={require("assets/img/avatar.jpg").default} />
										</div>
										<div className="worker-details">
											<div className="worker-help">
												<span className="worker-title">Name :</span>
												<span className="worker-info">{m.name}</span>
											</div>
											<div className="worker-help">
												<span className="worker-title">Gender :</span>
												<span className="worker-info">{m.gender}</span>
											</div>
											<div className="worker-help">
												<span className="worker-title">Address :</span>
												<span className="worker-info">{m.address}</span>
											</div>
											<div className="worker-help">
												<span className="worker-title">Age :</span>
												<span className="worker-info">{m.age}</span>
											</div>
                      <div className="worker-help">
												<span className="worker-title">Salary :</span>
												<span className="worker-info">{m.salary}</span>
											</div>
											<div className="review-btn">
												<Button className="btn-round mr-1" color="info" outline type="button">
												Review
												</Button>
											</div>
										</div>
									</Card>
									 </Col>
								)
							})
						}
                  </Row>  
                </div>
              </Col>
            </Row>
          </Container>
        </div>
        
      </div>
      <DemoFooter />
    </>
  );
}

export default DashboardPage;
