import React from "react";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import MaidHeader from "components/Headers/MaidHeader.js";
import Advantages from "views/index-sections/Advantages.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function MaidPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <MaidHeader />
      <div className="section service-content">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto text-center" md="8">
              <h2 className="sub-title">Are You Looking For A Reliable And Professional Maid Or Servant Service?</h2>
              <p className="about-info">
              House Help is one of the most trusted maid-servant service company, which provide immediate on demand Maid Services & housekeeping services in Pune. You can easily book a maid online through our online portal. for any type of maid services in Pune customers can visit us for professional, reliable and hardworking maids in Pune. We understand your time and requirements and therefore provide you quality maid services with the most professional workers in Pune. With Quality as our core value within a short period of time we have become one of the best service provider in Pune. We are 100% committed to our client needs for delivering 100 % of our service promises. Our services include housekeeping services for corporates, house maintenance packages and servants in Pune. We also provide full time maid services as well as part time maid services
              </p>
            </Col>
          </Row>
        </Container>
      </div>
      <Advantages />
      <DemoFooter />
    </>
  );
}

export default MaidPage;
