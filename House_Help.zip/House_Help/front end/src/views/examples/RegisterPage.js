
import React , { useState } from "react";
// reactstrap components
import { Button, Card, Form, Input, Container, Row, Col, Label, FormGroup} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";



async function registerUser(credentials) {
  
  

  fetch('http://localhost:5000/maid/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify(credentials)
  }).then(response => {

    //debugger;
     if(response.status != 201) 
      window.alert("Invalid username or password"); 
    else {
      window.alert("Registration successfull, you can login now"); 

      console.log(JSON.stringify(response))
      localStorage.setItem('Token', response.token);
      localStorage.setItem('Email', response.emailId);

      //history.push('/dashboard-page/');

      //return  <Redirect  to="/dashboard-page/" />
      //return  <Redirect  to="/dashboard-page" />

      window.location = '/login-page';
      //history.push('/dashboard-page');
    }
    }).then(data => {
      console.log(JSON.stringify(data))
    })

    
    
 }


function RegisterPage() {
  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("register-page");
    return function cleanup() {
      document.body.classList.remove("register-page");
    };
  });


  const [name, setName] = useState();
  const [address, setAddress] = useState();
  const [password, setPassword] = useState();
  const [mobile_no, setMobileNo] = useState();
  const [dob, setDOB] = useState();
  const [email_id, setEmailId] = useState();
  const [salary, setSalary] = useState();
  const [experience, setExperience] = useState();
  const [pin_code, setPin] = useState();
  const [age, setAge] = useState();
  const [gender, setGender] = useState();
  const [aadhar_no, setAdharNo] = useState();
  const [category, setCategory] = useState();
  const [city, setCity] = useState();


  const handleSubmit = async e => {
    e.preventDefault();
    const token = await registerUser({
      name,
      address,
      password,
      mobile_no,
      dob,
      email_id,
      salary,
      experience,
      pin_code,
      age,
      gender,
      aadhar_no,
      category,
      city
    });
    //setToken(token);
  }



  return (
    <>
      <IndexNavbar />
      <div
        className="page-header"
        style={{
          backgroundImage:
            "url(" + require("assets/img/hero-banner.jpg").default + ")",
        }}
      >
        <div className="filter" />
        <Container>
          <Row>
            <Col className="ml-auto mr-auto" lg="8">
              <Card className="card-register card-register-width  ml-auto mr-auto">
                <h3 className="title mx-auto">Welcome</h3>
                <Form className="register-form" onSubmit={handleSubmit}>
                  <div className="radio-box">
                    <div className="form-check-radio">
                      <Label check>
                        <Input
                          defaultChecked
                          defaultValue="option1"
                          id="exampleRadios1"
                          name="exampleRadios"
                          type="radio"
                        />
                        Normal User <span className="form-check-sign" />
                      </Label>
                    </div>
                     
                    <div className="form-check-radio">
                      <Label check>
                        <Input
                          defaultValue="option2"
                          id="exampleRadios2"
                          name="exampleRadios"
                          type="radio"
                        />
                        As a helper <span className="form-check-sign" />
                      </Label>
                    </div>
                  </div>
                  <Row>
                    <Col className="ml-auto mr-auto" lg="6">
                      <label>Full Name</label>
                      <Input placeholder="Enter name" type="text" onChange={e => setName(e.target.value)}  />
                      <label>Mobile Number</label>
                      <Input placeholder="Enter mobile" type="number" onChange={e => setMobileNo(e.target.value)} />
                      <label>Email</label>
                      <Input placeholder="Email" type="email" onChange={e => setEmailId(e.target.value)} />
                      <label>Password</label>
                      <Input placeholder="Password" type="password"  onChange={e => setPassword(e.target.value)}/>
                      <label>Salary</label>
                      <Input placeholder="Enter salary" type="text" onChange={e => setSalary(e.target.value)}/>
                      <label>Address</label>
                      <Input placeholder="Enter Address" type="text" onChange={e => setAddress(e.target.value)}/>
                      <label>City</label>
                      <Input placeholder="Enter city" type="text" onChange={e => setCity(e.target.value)}/>
                    </Col>
                    <Col className="ml-auto mr-auto" lg="6">
                      <label>PIN Code</label>
                      <Input placeholder="pin" type="number" onChange={e => setPin(e.target.value)} />
                      <label>Gender</label>
                      <Input placeholder="Enter Gender" type="text" onChange={e => setGender(e.target.value)} />
                      <label>Age</label>
                      <Input placeholder="Enter age" type="number" onChange={e => setAge(e.target.value)} />
                      <label>Date of Birth</label>
                      <Input placeholder="Select Date" type="Date" onChange={e => setDOB(e.target.value)}/>
                      <label>Aadhar No</label>
                      <Input placeholder="Enter aadhar" type="number" onChange={e => setAdharNo(e.target.value)} />
                      <label>Category</label>
                      <Input placeholder="Enter category" type="text" onChange={e => setCategory(e.target.value)} />
                      <label>Experience</label>
                      <Input placeholder="Enter Experience" type="number" onChange={e => setExperience(e.target.value)} />
                    </Col>
                  </Row>  
                  <Button block className="btn-round" color="danger" type="submit">
                    Register
                  </Button>
                </Form>
              </Card>
            </Col>
          </Row>
        </Container>
        <div className="footer register-footer text-center">
          <h6>
            © {new Date().getFullYear()}, House Help.  All rights reserved.
          </h6>
        </div>
      </div>
    </>
  );
}

export default RegisterPage;
