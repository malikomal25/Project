import React from "react";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import BabySitterHeader from "components/Headers/BabySitterHeader.js";
import Advantages from "views/index-sections/Advantages.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function ServicesBabysitterPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <BabySitterHeader />
      <div className="section service-content">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto text-center" md="8">
              <h2 className="sub-title">Are You Looking For A Reliable And Professional Babysitter/Eldercare?</h2>
              <p className="about-info">
              House Help is committed to affording peace of mind by offering a stress-free way of securing the best possible care for their children as well as seniors provided by most trusted, skilled and dependable professional workers. We provide guaranteed satisfaction to our customers, as our babysitter and eldercare services are well experienced and verified. Each selected babysitter/eldercare exhibits an intuitive care, and inspired desire to deliver the best experience to our customers. Each of our babysitter provided are assessed thoroughly to make sure that we provide highly talented baby care professionals for infants and babies, we also provide female babysitters who take care of all activities and physical health of the babies by serving them proper food and handle them with affection and warmth. We also provide reliable and trained patient care professionals for giving complete care to old people by serving them with humble approach.
              </p>
            </Col>
          </Row>
        </Container>
      </div>
      <Advantages />
      <DemoFooter />
    </>
  );
}

export default ServicesBabysitterPage;
