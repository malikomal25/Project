import React from "react";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import PageHeader from "components/Headers/PageHeader.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function AboutPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <PageHeader />
      <div className="section profile-content">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto text-center" md="8">
              <p className="about-info">
              House Help is one of the leading service provider for Maid, Cook, Babysitter, Driver, Servant, Eldercare, Gardener and Pantry Boy. We help customers and businesses to hire trusted professionals for all their service needs. We are staffed with young, passionate people working to make a difference in the lives of people by catering to their housekeeping service needs. We aim to solve the customer pain by keeping trust, safety and quality factors in mind. All the services are performed by well-trained professional’s domestic workers which gives 100 percent customer satisfaction to our valuable customers.
              </p>
            </Col>
          </Row>
          <Row>
            <Col className="ml-auto mr-auto" md="8">
              <h3 className="title text-center">How we are different from others</h3>
              <ul className="list">
                <li>Full Responsibility & Accountability</li>
                <li>We help customers to hire professional workers, and our workers serve to customers directly without any hassle.</li>
                <li>Proper Verification and Background Check with Proof</li>
                <li>365 Days Customer Support</li>
                <li>We do police verification as well as criminal court record check of the worker</li>
                <li>We are a govt. recognised startup having 25+ passionate team members</li>
              </ul>
            </Col>
          </Row>
        </Container>
      </div>
      <DemoFooter />
    </>
  );
}

export default AboutPage;
