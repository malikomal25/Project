import React from "react";

// reactstrap components
import {
  Button,
  Form,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import ContactHeader from "components/Headers/ContactHeader.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function ContactPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <ContactHeader />
      <div className="section contact-section">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto" md="4">
              <div className="adress-details">
                <h3>Address Details</h3>
                <div className="loc-address">2nd Floor, No.12 Ganesha Complex 10th Street, Shivajinagar Pune - 411003</div>
                <p><i class="fa fa-phone" aria-hidden="true"></i> Phone: +91-0987654321</p>
                <p><i class="fa fa-phone" aria-hidden="true"></i> Phone: +91-1234567890</p>
                <p><i class="fa fa-envelope-o" aria-hidden="true"></i> Email: support@househelp.com</p>
              </div>
            </Col>
            <Col className="ml-auto mr-auto" md="4">
              <div className="map-address">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15131.640321708732!2d73.8335447867299!3d18.532965143401643!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c0791d785177%3A0x20d86a81ca743dc8!2sShivajinagar%2C%20Pune%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1632883009517!5m2!1sen!2sin" width="100%" height="350" allowfullscreen="" loading="lazy"></iframe>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="section contct-section-2">
          <Container>
            <Row>
              <Col className="ml-auto mr-auto" md="8">
                <h2 className="text-center">Keep in touch?</h2>
                <Form className="contact-form">
                  <Row>
                    <Col md="6">
                      <label>Name</label>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="nc-icon nc-single-02" />
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input placeholder="Name" type="text" />
                      </InputGroup>
                    </Col>
                    <Col md="6">
                      <label>Email</label>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText>
                            <i className="nc-icon nc-email-85" />
                          </InputGroupText>
                        </InputGroupAddon>
                        <Input placeholder="Email" type="text" />
                      </InputGroup>
                    </Col>
                  </Row>
                  <label>Message</label>
                  <Input
                    placeholder="Tell us your thoughts and feelings..."
                    type="textarea"
                    rows="4"
                  />
                  <Row>
                    <Col className="ml-auto mr-auto" md="4">
                      <Button className="btn-fill" color="danger" size="lg">
                        Send Message
                      </Button>
                    </Col>
                  </Row>
                </Form>
              </Col>
            </Row>
          </Container>
        </div>
      <DemoFooter />
    </>
  );
}

export default ContactPage;
