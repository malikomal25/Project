import React from "react";

// reactstrap components
import {
  Container,
  Row,
  Col,
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import DriverHeader from "components/Headers/DriverHeader.js";
import Advantages from "views/index-sections/Advantages.js";
import DemoFooter from "components/Footers/DemoFooter.js";

function DriverPage() {
  const [activeTab, setActiveTab] = React.useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  };

  document.documentElement.classList.remove("nav-open");
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    return function cleanup() {
      document.body.classList.remove("landing-page");
    };
  });
  return (
    <>
      <IndexNavbar />
      <DriverHeader />
      <div className="section service-content">
        <Container>
          <Row>
            <Col className="ml-auto mr-auto text-center" md="8">
              <h2 className="sub-title">Are You Looking For A Reliable And Professional Driver?</h2>
              <p className="about-info">
              House Help  is one of the leading on demand service provider for assured quality services like maid, driver, cook, gardener, babysitter, eldercare and pantry boy. Be it providing a personal driver in Pune, or renting a driver we help customers to find the drivers within a very short period of time.
              </p>
            </Col>
          </Row>
        </Container>
      </div>
      <Advantages />
      <DemoFooter />
    </>
  );
}

export default DriverPage;
