import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch } from "react-router-dom";

// styles
import "bootstrap/scss/bootstrap.scss";
import "assets/scss/paper-kit.scss?v=1.3.0";
import "assets/demo/demo.css?v=1.3.0";
// pages
import Index from "views/Index.js";
import AboutPage from "views/examples/AboutPage.js";
import ContactPage from "views/examples/ContactPage.js";
import DashboardPage from "views/examples/DashboardPage.js";
import ServicesBabysitterPage from "views/examples/ServicesBabysitterPage.js";
import MaidPage from "views/examples/MaidPage.js";
import DriverPage from "views/examples/DriverPage.js";
import CookPage from "views/examples/CookPage.js";
import RegisterPage from "views/examples/RegisterPage.js";
import LoginPage from "views/examples/LoginPage.js";
import loginComp from "views/examples/login-com.js";
// others

ReactDOM.render(
  <BrowserRouter>
    <Switch>
      <Route 
        path="/index" 
        render={(props) => <Index {...props} />} />
      <Route
        path="/about-page"
        render={(props) => <AboutPage {...props} />}
      />
      <Route
        path="/contact-page"
        render={(props) => <ContactPage {...props} />}
      />
      <Route
        path="/baby-sitter"
        render={(props) => <ServicesBabysitterPage {...props} />}
      />
       <Route
        path="/maid-page"
        render={(props) => <MaidPage {...props} />}
      />
       <Route
        path="/driver-page"
        render={(props) => <DriverPage {...props} />}
      />
       <Route
        path="/cook-page"
        render={(props) => <CookPage {...props} />}
      />
      <Route
        path="/dashboard-page"
        render={(props) => <DashboardPage {...props} />}
      />
      <Route
        path="/register-page"
        render={(props) => <RegisterPage {...props} />}
      />
      <Route
        path="/login-page"
        render={(props) => <LoginPage {...props} />}
      />
      <Redirect to="/index" />
    </Switch>
  </BrowserRouter>,
  document.getElementById("root")
);
