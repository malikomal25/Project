
import React from "react";

// reactstrap components
import { Button, 
  Container,
  Row,
  Col,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText } from "reactstrap";

// core components

function SerachHeader() {
  let pageHeader = React.createRef();

  React.useEffect(() => {
    if (window.innerWidth < 991) {
      const updateScroll = () => {
        let windowScrollTop = window.pageYOffset / 3;
        pageHeader.current.style.transform =
          "translate3d(0," + windowScrollTop + "px,0)";
      };
      window.addEventListener("scroll", updateScroll);
      return function cleanup() {
        window.removeEventListener("scroll", updateScroll);
      };
    }
  });

  return (
    <>
      <div
        style={{
          backgroundImage:
            "url(" + require("assets/img/hero-banner.jpg").default + ")",
        }}
        className="page-header page-header-xs"
        data-parallax={true}
        ref={pageHeader}
      >
        <div className="serach-section">
          <Container>
            <Row>
              <Col className="ml-auto mr-auto" md="12">
                <h3 className="title">Dashboard</h3>
              </Col>
              <Col className="ml-auto mr-auto" md="12">
                <div className="serach-box">
                  <p>Find Professional and Reliable Workers</p>
                  <InputGroup>
                    <InputGroupAddon addonType="prepend">
                      <InputGroupText><i className="fa fa-search" aria-hidden="true"></i></InputGroupText>
                    </InputGroupAddon>
                      <Input type="text" placeholder="Search helper" />
                  </InputGroup>
                </div>
              </Col>
            </Row>
          </Container>    
        </div>
      </div>
    </>
  );
}

export default SerachHeader;
