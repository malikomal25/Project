import React from 'react';
import Header from './header/header'
import Login from './login/login';
import Register from './register/register';

class MainApp extends React.Component {
  render() {
    return <div>
      <Header/>
      <Login/>
    </div>;
  }
}

export default MainApp;